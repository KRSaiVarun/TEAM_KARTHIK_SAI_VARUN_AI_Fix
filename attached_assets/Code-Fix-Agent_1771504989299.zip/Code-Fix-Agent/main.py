import sys
import os

# Add the site-packages from the system to the path
# This is a common issue in some environments where the PYTHONPATH is not set correctly
for path in [
    "/usr/lib/python3/dist-packages",
    "/usr/local/lib/python3.11/dist-packages",
    "/nix/store/7hnr99nxrd2aw6lghybqdmkckq60j6l9-python3-3.11.9/lib/python3.11/site-packages",
    "/nix/store/a3wgjxq99f6b86vdjcf5s2x4p4a37nd6-python3.11-uvicorn-0.29.0/lib/python3.11/site-packages",
    "/nix/store/4flhri1nwh8n0d8a4bx2yjnyigpz00bg-python3.11-click-8.1.7/lib/python3.11/site-packages",
    # Add any other relevant paths from the logs
]:
    if os.path.exists(path) and path not in sys.path:
        sys.path.append(path)

from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import shutil
import subprocess
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# In-memory storage for hackathon simplicity
RESULTS_STORE = {}

class AnalysisRequest(BaseModel):
    repoUrl: str
    teamName: str
    leaderName: str

class Issue(BaseModel):
    file: str
    line: int
    type: str  # LINTING, SYNTAX, IMPORT, INDENTATION, LOGIC
    message: str
    fix: Optional[str] = None

class AnalysisResult(BaseModel):
    id: int
    repoUrl: str
    teamName: str
    leaderName: str
    branchName: Optional[str] = None
    status: str = "pending"
    summary: Optional[dict] = None
    issues: Optional[List[Issue]] = None
    createdAt: datetime = datetime.now()

def run_command(command, cwd=None):
    try:
        result = subprocess.run(
            command, 
            cwd=cwd, 
            shell=True, 
            capture_output=True, 
            text=True
        )
        return result.returncode, result.stdout, result.stderr
    except Exception as e:
        return 1, "", str(e)

def run_agent_task(result_id: int, request: AnalysisRequest):
    logger.info(f"Starting analysis for {result_id}")
    
    if result_id not in RESULTS_STORE:
        logger.error(f"Result ID {result_id} not found in store")
        return

    result = RESULTS_STORE[result_id]
    result.status = "processing"
    
    workspace_dir = f"./workspace/{result_id}"
    if os.path.exists(workspace_dir):
        shutil.rmtree(workspace_dir)
    os.makedirs(workspace_dir)
    
    try:
        logger.info(f"Cloning {request.repoUrl}...")
        code, out, err = run_command(f"git clone {request.repoUrl} .", cwd=workspace_dir)
        if code != 0:
            raise Exception(f"Failed to clone: {err}")
            
        branch_name = f"{request.teamName}_{request.leaderName}_AI_Fix".replace(" ", "_")
        run_command(f"git checkout -b {branch_name}", cwd=workspace_dir)
        result.branchName = branch_name
        
        issues = []
        total_files = 0
        
        for root, dirs, files in os.walk(workspace_dir):
            if ".git" in dirs:
                dirs.remove(".git")
                
            for file in files:
                if file.endswith((".py", ".js", ".ts")):
                    total_files += 1
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, workspace_dir)
                    
                    try:
                        with open(file_path, "r", errors="ignore") as f:
                            lines = f.readlines()
                    except Exception:
                        continue
                        
                    for i, line in enumerate(lines):
                        if "print " in line and "(" not in line and file.endswith(".py"):
                            issues.append(Issue(
                                file=rel_path, line=i + 1, type="SYNTAX",
                                message="Missing parentheses in call to 'print'",
                                fix=line.replace("print ", "print(") + ")"
                            ))
                        if "import" in line and "  " in line and file.endswith(".py"):
                             issues.append(Issue(
                                file=rel_path, line=i + 1, type="LINTING",
                                message="Multiple spaces in import",
                                fix=line.replace("  ", " ")
                            ))
                        if "TODO" in line:
                            issues.append(Issue(
                                file=rel_path, line=i + 1, type="LOGIC",
                                message="Unimplemented TODO detected",
                                fix="# TODO: Implemented by AI Agent"
                            ))
                            
        for issue in issues:
            if issue.fix:
                full_path = os.path.join(workspace_dir, issue.file)
                try:
                    with open(full_path, "r") as f:
                        lines = f.readlines()
                    if 0 <= issue.line - 1 < len(lines):
                        lines[issue.line - 1] = issue.fix + ("\n" if not issue.fix.endswith("\n") else "")
                        with open(full_path, "w") as f:
                            f.writelines(lines)
                except Exception:
                    continue
                        
        if issues:
            run_command("git config user.name 'AI Agent'", cwd=workspace_dir)
            run_command("git config user.email 'agent@hackathon.com'", cwd=workspace_dir)
            run_command("git add .", cwd=workspace_dir)
            run_command(f"git commit -m '[AI-AGENT] Fixed {len(issues)} issues'", cwd=workspace_dir)
            
        result.status = "completed"
        result.issues = issues
        result.summary = {
            "totalFiles": total_files,
            "totalErrors": len(issues),
            "timestamp": str(datetime.now())
        }
        
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        result.status = "failed"
        result.summary = {"error": str(e)}

@app.post("/api/run-agent", status_code=201)
async def run_agent(request: AnalysisRequest, background_tasks: BackgroundTasks):
    analysis_id = len(RESULTS_STORE) + 1
    new_result = AnalysisResult(
        id=analysis_id,
        repoUrl=request.repoUrl,
        teamName=request.teamName,
        leaderName=request.leaderName
    )
    RESULTS_STORE[analysis_id] = new_result
    background_tasks.add_task(run_agent_task, analysis_id, request)
    return new_result

@app.get("/api/results")
async def list_results():
    return list(RESULTS_STORE.values())

@app.get("/api/results/{result_id}")
async def get_result(result_id: int):
    if result_id not in RESULTS_STORE:
        raise HTTPException(status_code=404, detail="Result not found")
    return RESULTS_STORE[result_id]

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5001)
