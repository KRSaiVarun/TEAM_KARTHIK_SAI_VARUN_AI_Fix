## Packages
framer-motion | Smooth animations for the terminal logs and UI transitions
date-fns | Formatting timestamps for the history log
clsx | Conditional class names utility
tailwind-merge | Utility to merge tailwind classes properly

## Notes
The backend provides analysis results. 
We will poll the status on the details page if it's 'pending' or 'processing'.
The design will be a modern, dark-themed developer tool aesthetic.
