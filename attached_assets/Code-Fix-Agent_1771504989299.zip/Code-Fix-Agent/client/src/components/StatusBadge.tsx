import { cn } from "@/lib/utils";
import { Loader2, CheckCircle2, XCircle, Clock } from "lucide-react";

type Status = "pending" | "processing" | "completed" | "failed";

interface StatusBadgeProps {
  status: string; // Using string to accept raw DB values, but effectively Status
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = {
    pending: {
      color: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
      icon: Clock,
      label: "Pending",
    },
    processing: {
      color: "bg-blue-500/10 text-blue-500 border-blue-500/20",
      icon: Loader2,
      label: "Processing",
      spin: true,
    },
    completed: {
      color: "bg-green-500/10 text-green-500 border-green-500/20",
      icon: CheckCircle2,
      label: "Completed",
    },
    failed: {
      color: "bg-red-500/10 text-red-500 border-red-500/20",
      icon: XCircle,
      label: "Failed",
    },
  };

  const current = config[status as Status] || config.pending;
  const Icon = current.icon;

  return (
    <div
      className={cn(
        "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border uppercase tracking-wider",
        current.color,
        className
      )}
    >
      <Icon className={cn("w-3.5 h-3.5", current.spin && "animate-spin")} />
      {current.label}
    </div>
  );
}
