import { cn } from "@/lib/utils";
import { AlertTriangle, AlertCircle, FileCode, Check, X } from "lucide-react";
import { motion } from "framer-motion";

interface Issue {
  file: string;
  line: number;
  type: "LINTING" | "SYNTAX" | "IMPORT" | "INDENTATION" | "LOGIC";
  message: string;
  fix?: string;
}

export function IssueCard({ issue, index }: { issue: Issue; index: number }) {
  const typeColors = {
    LINTING: "text-yellow-500 bg-yellow-500/10 border-yellow-500/20",
    SYNTAX: "text-red-500 bg-red-500/10 border-red-500/20",
    IMPORT: "text-blue-500 bg-blue-500/10 border-blue-500/20",
    INDENTATION: "text-purple-500 bg-purple-500/10 border-purple-500/20",
    LOGIC: "text-orange-500 bg-orange-500/10 border-orange-500/20",
  };

  const isFixable = !!issue.fix;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="group bg-card border border-border/50 rounded-xl overflow-hidden hover:border-primary/30 transition-all duration-300"
    >
      {/* Header */}
      <div className="p-4 flex items-start justify-between gap-4 border-b border-border/30 bg-muted/20">
        <div className="flex items-center gap-3">
          <div className={cn("p-2 rounded-lg", typeColors[issue.type] || "text-gray-500 bg-gray-500/10")}>
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider", typeColors[issue.type])}>
                {issue.type}
              </span>
              <span className="text-xs text-muted-foreground font-mono flex items-center gap-1">
                <FileCode className="w-3 h-3" />
                {issue.file}:{issue.line}
              </span>
            </div>
            <p className="text-sm font-medium text-foreground">{issue.message}</p>
          </div>
        </div>
        
        {isFixable ? (
          <div className="flex items-center gap-1 text-xs font-medium text-green-500 bg-green-500/10 px-2 py-1 rounded-md border border-green-500/20">
            <Check className="w-3 h-3" />
            <span>Auto-Fixed</span>
          </div>
        ) : (
          <div className="flex items-center gap-1 text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-md border border-border">
            <X className="w-3 h-3" />
            <span>Manual Fix Needed</span>
          </div>
        )}
      </div>

      {/* Code / Fix Section */}
      {isFixable && (
        <div className="p-0 bg-[#0d1117]">
          <div className="flex">
            <div className="w-1 bg-green-500/50"></div>
            <div className="flex-1 p-4 font-mono text-xs overflow-x-auto">
              <div className="flex items-center gap-2 text-green-400 mb-2 opacity-70 uppercase tracking-widest text-[10px]">
                <Check className="w-3 h-3" />
                Applied Fix
              </div>
              <pre className="text-gray-300 whitespace-pre-wrap">{issue.fix}</pre>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
