import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { InsertAnalysis, AnalysisResult } from "@shared/schema";

// GET /api/results - List all analyses
export function useAnalysisResults() {
  return useQuery({
    queryKey: [api.agent.list.path],
    queryFn: async () => {
      const res = await fetch(api.agent.list.path);
      if (!res.ok) throw new Error("Failed to fetch history");
      // Validate with Zod schema from api definition
      return api.agent.list.responses[200].parse(await res.json());
    },
    // Refresh fairly often as this is a dashboard
    refetchInterval: 5000, 
  });
}

// GET /api/results/:id - Get specific analysis details
export function useAnalysisResult(id: number) {
  return useQuery({
    queryKey: [api.agent.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.agent.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch analysis details");
      return api.agent.get.responses[200].parse(await res.json());
    },
    // Poll more frequently if the status is active
    refetchInterval: (query) => {
      const data = query.state.data as AnalysisResult | undefined;
      if (data?.status === "pending" || data?.status === "processing") {
        return 2000; // Poll every 2s while running
      }
      return false; // Stop polling when done
    },
  });
}

// POST /api/run-agent - Start a new analysis
export function useRunAgent() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: InsertAnalysis) => {
      // Validate input before sending (though Zod on backend handles it too)
      const validated = api.agent.run.input.parse(data);
      
      const res = await fetch(api.agent.run.path, {
        method: api.agent.run.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.message || "Failed to start agent");
      }

      return api.agent.run.responses[201].parse(await res.json());
    },
    onSuccess: (data) => {
      toast({
        title: "Agent Started",
        description: `Analyzing ${data.repoUrl}...`,
      });
      queryClient.invalidateQueries({ queryKey: [api.agent.list.path] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
