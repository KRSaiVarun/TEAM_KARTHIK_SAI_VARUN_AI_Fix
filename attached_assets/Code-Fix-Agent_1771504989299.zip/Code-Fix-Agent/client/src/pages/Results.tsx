import { useRoute } from "wouter";
import { useAnalysisResult } from "@/hooks/use-analysis";
import { Layout } from "@/components/Layout";
import { StatusBadge } from "@/components/StatusBadge";
import { IssueCard } from "@/components/IssueCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { GitBranch, Github, AlertCircle, CheckCircle2, FileText, ArrowLeft, Terminal } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Results() {
  const [, params] = useRoute("/results/:id");
  const id = parseInt(params?.id || "0");
  const { data, isLoading, error } = useAnalysisResult(id);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full animate-pulse"></div>
            <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin relative z-10"></div>
          </div>
          <p className="text-xl font-medium animate-pulse text-muted-foreground">Loading Analysis Data...</p>
        </div>
      </Layout>
    );
  }

  if (error || !data) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center h-[60vh] space-y-4 text-center">
          <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mb-4">
            <AlertCircle className="w-8 h-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold">Analysis Not Found</h1>
          <p className="text-muted-foreground max-w-md">The analysis request you are looking for does not exist or an error occurred.</p>
          <Link href="/">
            <Button variant="outline" className="mt-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </Layout>
    );
  }

  // Parse issues if they are stored as JSON string (depending on DB response format quirks)
  const issues = Array.isArray(data.issues) ? data.issues : [];
  const summary = data.summary as { totalFiles: number; totalErrors: number; timestamp: string } | null;

  return (
    <Layout>
      <div className="space-y-8 pb-12">
        {/* Header Breadcrumb */}
        <Link href="/">
          <Button variant="ghost" size="sm" className="pl-0 text-muted-foreground hover:text-primary">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>

        {/* Hero Summary Card */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="md:col-span-2 lg:col-span-2 glass-card border-l-4 border-l-primary overflow-hidden relative">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Github className="w-32 h-32" />
            </div>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <StatusBadge status={data.status} className="mb-2" />
                <span className="text-xs font-mono text-muted-foreground">ID: #{data.id}</span>
              </div>
              <CardTitle className="text-2xl font-bold break-all">
                {data.repoUrl.replace("https://github.com/", "")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-2 bg-muted/50 px-3 py-1.5 rounded-md border border-border/50">
                  <GitBranch className="w-4 h-4 text-primary" />
                  <span className="font-mono">{data.branchName || "..."}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground/60">Leader:</span>
                  <span className="font-medium text-foreground">{data.leaderName}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Issues Found</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-foreground flex items-baseline gap-2">
                {summary?.totalErrors || issues.length || 0}
                <span className="text-sm font-normal text-muted-foreground">bugs</span>
              </div>
              <div className="mt-2 h-1.5 w-full bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-destructive" 
                  style={{ width: `${Math.min(((summary?.totalErrors || 0) / 20) * 100, 100)}%` }}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Files Analyzed</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-foreground flex items-baseline gap-2">
                {summary?.totalFiles || 0}
                <span className="text-sm font-normal text-muted-foreground">files</span>
              </div>
              <div className="flex items-center gap-1 mt-2 text-xs text-green-500">
                <CheckCircle2 className="w-3 h-3" />
                <span>Scan Complete</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Status Pipeline Visualization */}
        <div className="relative pt-8 pb-8">
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-border -translate-y-1/2 hidden md:block" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative z-10">
            {['queued', 'cloning', 'analyzing', 'completed'].map((step, idx) => {
              // Simplified logic for visual progress steps
              const isCompleted = data.status === 'completed' || (data.status === 'processing' && idx < 2);
              const isCurrent = data.status === 'processing' && idx === 2; // Fake progress logic for demo
              
              return (
                <div key={step} className="flex flex-col items-center text-center bg-background md:bg-transparent p-4 md:p-0 rounded-lg border md:border-0">
                  <div className={`
                    w-10 h-10 rounded-full flex items-center justify-center border-2 mb-3 transition-colors duration-500
                    ${isCompleted ? 'bg-primary border-primary text-primary-foreground' : 
                      isCurrent ? 'bg-background border-primary text-primary animate-pulse' : 
                      'bg-muted border-border text-muted-foreground'}
                  `}>
                    {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : <div className="text-xs font-bold">{idx + 1}</div>}
                  </div>
                  <span className={`text-sm font-medium uppercase tracking-wide ${isCompleted || isCurrent ? 'text-foreground' : 'text-muted-foreground'}`}>
                    {step}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Logs & Issues Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Detailed Issues List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                Detected Issues
              </h2>
              <div className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                Showing {issues.length} items
              </div>
            </div>

            {issues.length === 0 ? (
              <Card className="border-dashed border-2 border-border bg-transparent">
                <CardContent className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                  <CheckCircle2 className="w-12 h-12 mb-4 text-green-500/50" />
                  <p className="text-lg font-medium">No issues detected!</p>
                  <p className="text-sm">Great job, your code looks clean.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {issues.map((issue: any, index: number) => (
                  <IssueCard key={index} issue={issue} index={index} />
                ))}
              </div>
            )}
          </div>

          {/* Terminal Log Panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="bg-[#0d1117] border border-border/50 rounded-xl overflow-hidden shadow-2xl">
                <div className="bg-[#161b22] px-4 py-2 flex items-center gap-2 border-b border-border/30">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500/80" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                    <div className="w-3 h-3 rounded-full bg-green-500/80" />
                  </div>
                  <span className="ml-2 text-xs font-mono text-muted-foreground flex items-center gap-1">
                    <Terminal className="w-3 h-3" />
                    agent-log.txt
                  </span>
                </div>
                <div className="p-4 font-mono text-xs space-y-2 h-[400px] overflow-y-auto text-gray-400">
                  <div className="text-green-500">$ agent start --repo {data.repoUrl}</div>
                  <div>[INFO] Initializing agent...</div>
                  <div>[INFO] Cloning repository...</div>
                  {data.status !== 'pending' && (
                    <>
                      <div className="text-blue-400">[PROCESS] Analysis started on main branch</div>
                      <div>[INFO] Scanning files...</div>
                      {issues.map((issue: any, i: number) => (
                        <div key={i} className="text-yellow-500/80 pl-2">
                          ⚠ Found {issue.type} issue in {issue.file}:{issue.line}
                        </div>
                      ))}
                    </>
                  )}
                  {data.status === 'completed' && (
                    <>
                      <div className="text-green-500">[SUCCESS] Analysis complete.</div>
                      <div className="text-blue-400">[ACTION] Creating fix branch: {data.branchName}</div>
                      <div>[INFO] Pushing changes...</div>
                      <div className="text-green-500 font-bold">✨ Done. {summary?.totalErrors} fixes applied.</div>
                    </>
                  )}
                  {data.status === 'failed' && (
                    <div className="text-red-500 font-bold">[ERROR] Process failed unexpectedly.</div>
                  )}
                  <motion.div 
                    animate={{ opacity: [0, 1, 0] }} 
                    transition={{ repeat: Infinity, duration: 0.8 }}
                    className="w-2 h-4 bg-gray-500 inline-block align-middle ml-1"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
