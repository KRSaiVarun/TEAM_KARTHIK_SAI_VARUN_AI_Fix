import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertAnalysisSchema, type InsertAnalysis } from "@shared/schema";
import { useRunAgent, useAnalysisResults } from "@/hooks/use-analysis";
import { Layout } from "@/components/Layout";
import { StatusBadge } from "@/components/StatusBadge";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Play, GitBranch, User, Github, ArrowRight, Loader2, History } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const runAgent = useRunAgent();
  const { data: history, isLoading: isHistoryLoading } = useAnalysisResults();

  const form = useForm<InsertAnalysis>({
    resolver: zodResolver(insertAnalysisSchema),
    defaultValues: {
      repoUrl: "",
      teamName: "",
      leaderName: "",
    },
  });

  async function onSubmit(data: InsertAnalysis) {
    try {
      const result = await runAgent.mutateAsync(data);
      setLocation(`/results/${result.id}`);
    } catch (error) {
      // Handled by mutation hook toast
    }
  }

  // Define some nice gradient backgrounds for the cards
  const gradients = [
    "from-purple-500/10 to-blue-500/10 border-purple-500/20 hover:border-purple-500/40",
    "from-green-500/10 to-emerald-500/10 border-green-500/20 hover:border-green-500/40",
    "from-orange-500/10 to-red-500/10 border-orange-500/20 hover:border-orange-500/40",
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Input Form */}
        <div className="lg:col-span-2 space-y-8">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
              AI Code Agent
            </h1>
            <p className="text-lg text-muted-foreground">
              Automated bug detection and fixing for your GitHub repositories.
            </p>
          </div>

          <Card className="glass-card border-primary/20 shadow-primary/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TerminalIcon className="w-5 h-5 text-primary" />
                Start New Analysis
              </CardTitle>
              <CardDescription>
                Enter your repository details to let the agent clone, analyze, and fix issues.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="repoUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>GitHub Repository URL</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Github className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input 
                              placeholder="https://github.com/username/repo" 
                              className="pl-10 font-mono bg-background/50 border-input focus:border-primary/50 focus:ring-primary/20 transition-all" 
                              {...field} 
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="teamName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Team Name</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <GitBranch className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                              <Input placeholder="Engineering A" className="pl-10 bg-background/50" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="leaderName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Leader Name</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                              <Input placeholder="Jane Doe" className="pl-10 bg-background/50" {...field} />
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={runAgent.isPending}
                    className="w-full h-12 text-lg font-semibold bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground shadow-lg shadow-primary/20"
                  >
                    {runAgent.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                        Initializing Agent...
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-5 w-5 fill-current" />
                        Run Agent
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Recent History */}
        <div className="lg:col-span-1 space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <History className="w-5 h-5 text-muted-foreground" />
            <h2 className="text-xl font-semibold">Recent Runs</h2>
          </div>

          <div className="space-y-4">
            {isHistoryLoading ? (
              <div className="flex items-center justify-center h-40 text-muted-foreground">
                <Loader2 className="w-6 h-6 animate-spin mr-2" />
                Loading history...
              </div>
            ) : history?.length === 0 ? (
              <div className="text-center p-8 border border-dashed border-border rounded-xl text-muted-foreground">
                No analysis history found.
              </div>
            ) : (
              history?.map((item, idx) => (
                <Link key={item.id} href={`/results/${item.id}`}>
                  <div className={`
                    group relative p-4 rounded-xl border bg-gradient-to-br transition-all duration-300 cursor-pointer
                    hover:-translate-y-1 hover:shadow-lg
                    ${gradients[idx % gradients.length]}
                  `}>
                    <div className="flex justify-between items-start mb-2">
                      <StatusBadge status={item.status} />
                      <span className="text-xs text-muted-foreground">
                        {item.createdAt && formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                    <h3 className="font-semibold text-foreground truncate mb-1">
                      {item.repoUrl.split('/').slice(-2).join('/')}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <GitBranch className="w-3 h-3" />
                      {item.branchName || "pending-branch"}
                    </div>
                    
                    <div className="absolute right-4 bottom-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ArrowRight className="w-4 h-4 text-primary" />
                    </div>
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

function TerminalIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="4 17 10 11 4 5" />
      <line x1="12" x2="20" y1="19" y2="19" />
    </svg>
  );
}
