
import { z } from 'zod';
import { insertAnalysisSchema, analysisResults } from './schema';

// ============================================
// API CONTRACT
// ============================================
export const api = {
  agent: {
    run: {
      method: 'POST' as const,
      path: '/api/run-agent' as const,
      input: insertAnalysisSchema,
      responses: {
        201: z.custom<typeof analysisResults.$inferSelect>(),
        400: z.object({ message: z.string() }),
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/results' as const,
      responses: {
        200: z.array(z.custom<typeof analysisResults.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/results/:id' as const,
      responses: {
        200: z.custom<typeof analysisResults.$inferSelect>(),
        404: z.object({ message: z.string() }),
      },
    }
  },
};

// ============================================
// HELPER
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
