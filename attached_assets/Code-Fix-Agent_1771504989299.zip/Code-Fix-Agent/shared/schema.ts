
import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===
// We'll use a simple schema to store analysis results
export const analysisResults = pgTable("analysis_results", {
  id: serial("id").primaryKey(),
  repoUrl: text("repo_url").notNull(),
  teamName: text("team_name").notNull(),
  leaderName: text("leader_name").notNull(),
  branchName: text("branch_name"),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  summary: jsonb("summary").$type<{
    totalFiles: number;
    totalErrors: number;
    timestamp: string;
  }>(),
  issues: jsonb("issues").$type<Array<{
    file: string;
    line: number;
    type: "LINTING" | "SYNTAX" | "IMPORT" | "INDENTATION" | "LOGIC";
    message: string;
    fix?: string;
  }>>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// === BASE SCHEMAS ===
export const insertAnalysisSchema = createInsertSchema(analysisResults).omit({ 
  id: true, 
  createdAt: true,
  status: true,
  branchName: true,
  summary: true,
  issues: true
});

// === EXPLICIT API CONTRACT TYPES ===
export type AnalysisResult = typeof analysisResults.$inferSelect;
export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;

// Request types
export type RunAgentRequest = InsertAnalysis;

// Response types
export type AnalysisResponse = AnalysisResult;
export type AnalysisListResponse = AnalysisResult[];
